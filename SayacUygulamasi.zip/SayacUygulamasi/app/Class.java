import android.content.Context;
import android.content.SharedPreferences;

public class Class {
    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    static Class sClass= null;

    private Class(Context context){
        this.context=context;
        sharedPreferences=context.getSharedPreferences("setup",Context.MODE_PRIVATE);
    }
    public static Class getInstance(Context context){
        if(sClass==null){
            sClass=new Class(context);
        }
        return sClass;
    }
}

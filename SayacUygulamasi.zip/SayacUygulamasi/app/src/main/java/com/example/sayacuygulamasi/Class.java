package com.example.sayacuygulamasi;

import android.content.Context;
import android.content.SharedPreferences;

public class Class {
    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    static Class setupClass=null;

    private Class(Context context){
        this.context=context;
        sharedPreferences=context.getSharedPreferences("setup",Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    public static Class getInstance(Context context){
        if(setupClass==null){
            setupClass=new Class(context);
        }
        return setupClass;
    }
}

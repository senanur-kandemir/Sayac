package com.example.sayacuygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SetupActivity extends AppCompatActivity {

    Button s_plus,s_minus;
    EditText s_value;
    int upLimit=0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        SharedPreferences sharedPreferences;
        SharedPreferences.Editor editor;

        s_plus=(Button) findViewById(R.id.s_plus);
        s_minus=(Button) findViewById(R.id.s_minus);
        s_value=(EditText) findViewById(R.id.s_value);

        Context context=getApplicationContext();
        sharedPreferences=context.getSharedPreferences(context.getPackageName(),Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();
        //sharedpreferences ile verilere erişildi private mode ile.

        s_value.setText(String.valueOf(upLimit));
        s_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                upLimit++;
                s_value.setText((String.valueOf(upLimit)));
            }
        });

        s_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                upLimit--;
                s_value.setText((String.valueOf(upLimit)));
            }
        });
    }
}